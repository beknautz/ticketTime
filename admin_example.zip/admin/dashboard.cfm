<!--- admin/dashboard.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfset request.pageTitle = "Dashboard">

<cfquery name="stats" datasource="#application.dsn#">
  SELECT
    (SELECT COUNT(*) FROM products WHERE is_active = 1)    AS total_products,
    (SELECT COUNT(*) FROM products WHERE is_featured = 1)  AS featured_products,
    (SELECT COUNT(*) FROM products WHERE is_new = 1)       AS new_products,
    (SELECT COUNT(*) FROM categories WHERE is_active = 1)  AS total_categories
</cfquery>

<cfquery name="recentProducts" datasource="#application.dsn#">
  SELECT p.product_id, p.name, p.slug, p.price, p.is_active, p.created_at,
         c.name AS category_name
  FROM products p
  JOIN categories c ON c.category_id = p.category_id
  ORDER BY p.created_at DESC
  LIMIT 8
</cfquery>

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<!--- Stats Grid --->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-card-num">#stats.total_products#</div>
    <div class="stat-card-label">Total Products</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-num">#stats.total_categories#</div>
    <div class="stat-card-label">Categories</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-num" style="color:var(--color-gold)">#stats.featured_products#</div>
    <div class="stat-card-label">Featured</div>
  </div>
  <div class="stat-card">
    <div class="stat-card-num" style="color:##75c99a">#stats.new_products#</div>
    <div class="stat-card-label">New Arrivals</div>
  </div>
</div>

<!--- Quick Actions --->
<div style="display:flex;gap:0.75rem;flex-wrap:wrap;margin-bottom:2rem">
  <a href="/admin/products_form.cfm" class="btn btn-fire btn-sm">
    <i class="bi bi-plus-lg"></i> Add Product
  </a>
  <a href="/admin/categories_list.cfm" class="btn btn-outline btn-sm">
    <i class="bi bi-tag"></i> Manage Categories
  </a>
  <a href="/admin/settings_home.cfm" class="btn btn-outline btn-sm">
    <i class="bi bi-house"></i> Edit Homepage
  </a>
  <a href="/admin/settings_general.cfm" class="btn btn-outline btn-sm">
    <i class="bi bi-gear"></i> Settings
  </a>
</div>

<!--- Recent Products --->
<div class="admin-card">
  <div class="admin-card-header">
    <h3>Recent Products</h3>
    <a href="/admin/products_list.cfm" style="font-size:0.8rem;color:var(--color-fire)">View All →</a>
  </div>
  <table class="admin-table">
    <thead>
      <tr>
        <th>Product</th>
        <th>Category</th>
        <th>Price</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <cfloop query="recentProducts">
      <tr>
        <td style="font-weight:600;color:var(--text-primary)">#htmlEditFormat(name)#</td>
        <td>#htmlEditFormat(category_name)#</td>
        <td>
          <cfif price GT 0>$#numberFormat(price, ",.00")#<cfelse><span style="color:var(--text-muted)">—</span></cfif>
        </td>
        <td>
          <cfif is_active>
            <span class="status-badge status-active"><i class="bi bi-circle-fill" style="font-size:0.4rem"></i> Active</span>
          <cfelse>
            <span class="status-badge status-inactive">Inactive</span>
          </cfif>
        </td>
        <td>
          <a href="/admin/products_form.cfm?product_id=#product_id#" class="btn btn-outline btn-sm">Edit</a>
        </td>
      </tr>
      </cfloop>
    </tbody>
  </table>
</div>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
