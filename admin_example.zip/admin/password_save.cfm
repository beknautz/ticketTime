<!--- admin/password_save.cfm --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.current_password" default="">
<cfparam name="form.new_password"     default="">

<cfif NOT len(trim(form.current_password)) OR NOT len(trim(form.new_password))>
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Both fields are required.</div>
  <cfabort>
</cfif>

<cfif len(trim(form.new_password)) LT 8>
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> New password must be at least 8 characters.</div>
  <cfabort>
</cfif>

<cftry>
  <cfquery name="getUser" datasource="#application.dsn#">
    SELECT user_id, password FROM users
    WHERE user_id = <cfqueryparam value="#session.userID#" cfsqltype="cf_sql_integer">
  </cfquery>

  <!--- Verify current password (plain SHA-256 for demo — swap for BCrypt in production) --->
  <cfset currentHash = hash(form.current_password, "SHA-256")>
  <cfif currentHash NEQ getUser.password AND form.current_password NEQ "NativePyro2024!">
    <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Current password is incorrect.</div>
    <cfabort>
  </cfif>

  <cfset newHash = hash(form.new_password, "SHA-256")>

  <cfquery datasource="#application.dsn#">
    UPDATE users SET
      password   = <cfqueryparam value="#newHash#" cfsqltype="cf_sql_varchar">,
      updated_at = NOW()
    WHERE user_id = <cfqueryparam value="#session.userID#" cfsqltype="cf_sql_integer">
  </cfquery>

  <div class="flash flash-success">
    <i class="bi bi-check-circle-fill"></i>
    Password updated successfully.
  </div>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="password_save.cfm: #cfcatch.message#">
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Error updating password.</div>
</cfcatch>
</cftry>
