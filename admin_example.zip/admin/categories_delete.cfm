<!--- admin/categories_delete.cfm — HTMX POST handler --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="form.category_id" default="0">

<cfif NOT val(form.category_id)>
  <cfabort>
</cfif>

<cftry>
  <!--- Check for products in this category --->
  <cfquery name="checkProducts" datasource="#application.dsn#">
    SELECT COUNT(*) AS total FROM products
    WHERE category_id = <cfqueryparam value="#val(form.category_id)#" cfsqltype="cf_sql_integer">
  </cfquery>

  <cfif checkProducts.total GT 0>
    <tr id="cat-row-#val(form.category_id)#">
      <td colspan="7" style="color:##f48995;padding:0.75rem 1rem;background:rgba(220,53,69,0.05)">
        <i class="bi bi-exclamation-circle-fill"></i>
        Cannot delete — this category has <cfoutput>#checkProducts.total#</cfoutput> product(s). Reassign or delete them first.
      </td>
    </tr>
    <cfabort>
  </cfif>

  <cfquery datasource="#application.dsn#">
    DELETE FROM categories
    WHERE category_id = <cfqueryparam value="#val(form.category_id)#" cfsqltype="cf_sql_integer">
  </cfquery>
  <!--- Empty return — HTMX removes the row --->

<cfcatch type="database">
  <cflog file="nativepyro_errors" text="categories_delete.cfm: #cfcatch.message#">
  <tr id="cat-row-<cfoutput>#val(form.category_id)#</cfoutput>">
    <td colspan="7" style="color:##f48995;padding:0.75rem 1rem">Delete failed. Please try again.</td>
  </tr>
</cfcatch>
</cftry>
