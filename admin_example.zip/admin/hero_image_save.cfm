<!--- admin/hero_image_save.cfm — Hero background image upload handler --->
<cfinclude template="/includes/auth_check.cfm">

<!---
  IMPORTANT — CF2023 Sandbox / Security Note
  =====================================================================
  Removed accept="image/*" from cffile — on locked-down CF2023 installs
  the MIME-type check reads the temp file via Java FilePermission which
  gets blocked by the security sandbox.  We validate the extension
  ourselves after upload instead, which avoids the temp-file read.
  ===================================================================== --->

<!--- Ensure the hero upload directory exists --->
<cfset uploadDir = expandPath("/assets/img/uploads/hero/")>
<cfif NOT directoryExists(uploadDir)>
  <cfdirectory action="create" directory="#uploadDir#">
</cfif>

<cftry>

  <!--- Validate a file field was submitted --->
  <cfif NOT structKeyExists(form, "hero_image_file") OR NOT len(trim(form.hero_image_file))>
    <div class="flash flash-danger">
      <i class="bi bi-exclamation-circle-fill"></i>
      Please select an image file to upload.
    </div>
    <cfabort>
  </cfif>

  <!---
    Upload WITHOUT accept= attribute.
    CF will move the file from its temp location to uploadDir.
    We check the extension ourselves immediately after.
  --->
  <cffile
    action="upload"
    filefield="hero_image_file"
    destination="#uploadDir#"
    nameconflict="makeunique"
  >

  <cfset savedFilename  = cffile.serverFile>
  <cfset fileExtension  = lCase(cffile.serverFileExt)>
  <cfset fileSizeBytes  = cffile.fileSize>
  <cfset allowedExts    = "jpg,jpeg,png,gif,webp">

  <!--- Extension validation — delete the uploaded file if not an image --->
  <cfif NOT listFind(allowedExts, fileExtension)>
    <cftry>
      <cffile action="delete" file="#uploadDir##savedFilename#">
    <cfcatch type="any"></cfcatch>
    </cftry>
    <cfoutput>
    <div class="flash flash-danger">
      <i class="bi bi-exclamation-circle-fill"></i>
      Invalid file type (.#htmlEditFormat(fileExtension)#). Only JPG, PNG, GIF, and WEBP are allowed.
    </div>
    </cfoutput>
    <cfabort>
  </cfif>

  <!--- File size guard: 10 MB max --->
  <cfif fileSizeBytes GT 10485760>
    <cftry>
      <cffile action="delete" file="#uploadDir##savedFilename#">
    <cfcatch type="any"></cfcatch>
    </cftry>
    <cfoutput>
    <div class="flash flash-danger">
      <i class="bi bi-exclamation-circle-fill"></i>
      File too large (#numberFormat(round(fileSizeBytes/1048576))# MB). Maximum is 10 MB.
    </div>
    </cfoutput>
    <cfabort>
  </cfif>

  <!--- Delete the previous hero image from disk --->
  <cfif structKeyExists(application.settings, "hero_image") AND len(trim(application.settings.hero_image))>
    <cfset oldFile = uploadDir & trim(application.settings.hero_image)>
    <cfif trim(application.settings.hero_image) NEQ savedFilename AND fileExists(oldFile)>
      <cftry>
        <cffile action="delete" file="#oldFile#">
      <cfcatch type="any"></cfcatch>
      </cftry>
    </cfif>
  </cfif>

  <!--- Persist to settings table --->
  <cfquery datasource="#application.dsn#">
    INSERT INTO settings (setting_key, setting_value)
    VALUES (
      <cfqueryparam value="hero_image" cfsqltype="cf_sql_varchar">,
      <cfqueryparam value="#savedFilename#" cfsqltype="cf_sql_varchar">
    )
    ON DUPLICATE KEY UPDATE
      setting_value = <cfqueryparam value="#savedFilename#" cfsqltype="cf_sql_varchar">
  </cfquery>

  <!--- Update live app scope so homepage reflects the change immediately --->
  <cfset application.settings.hero_image = savedFilename>

  <!--- Return success fragment --->
  <cfoutput>
  <div class="flash flash-success" style="margin-bottom:1rem">
    <i class="bi bi-check-circle-fill"></i>
    Hero image uploaded.
    <a href="#application.rootURL#/" target="_blank" style="color:var(--color-gold);margin-left:0.25rem">View on site →</a>
  </div>
  <div style="border-radius:var(--border-radius-lg);overflow:hidden;border:1px solid rgba(255,69,0,0.3);max-width:600px;position:relative">
    <img
      src="#application.rootURL#/assets/img/uploads/hero/#savedFilename#"
      alt="Hero background"
      style="width:100%;height:220px;object-fit:cover;display:block"
    >
    <div style="position:absolute;inset:0;background:linear-gradient(to right,rgba(255,69,0,0.4),transparent);pointer-events:none"></div>
    <div style="position:absolute;bottom:0.75rem;left:0.75rem;font-family:var(--font-heading);font-size:0.7rem;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.8)">Active hero image</div>
  </div>
  <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.4rem">
    File: #htmlEditFormat(savedFilename)# &nbsp;&middot;&nbsp; #numberFormat(round(fileSizeBytes/1024))# KB
  </div>
  </cfoutput>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="hero_image_save.cfm: #cfcatch.message# | #cfcatch.detail#">
  <cfoutput>
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    <strong>Upload failed:</strong> #htmlEditFormat(cfcatch.message)#
    <cfif findNoCase("FilePermission", cfcatch.message) OR findNoCase("access denied", cfcatch.message)>
      <br><span style="font-size:0.85em;opacity:0.8">This is a ColdFusion sandbox permissions issue — see fix below.</span>
    </cfif>
  </div>

  <cfif findNoCase("FilePermission", cfcatch.message) OR findNoCase("access denied", cfcatch.message)>
  <div style="background:var(--bg-elevated);border:1px solid var(--border-color);border-radius:var(--border-radius-lg);padding:1.5rem;margin-top:1rem;font-size:0.85rem;line-height:1.7">
    <div style="font-family:var(--font-heading);font-weight:700;font-size:0.8rem;letter-spacing:0.08em;text-transform:uppercase;color:var(--color-gold);margin-bottom:1rem">
      ⚠️ CF2023 Sandbox Fix Required
    </div>
    <p style="color:var(--text-secondary);margin-bottom:0.75rem">Two paths need <strong>Read/Write</strong> permission in CF Administrator:</p>
    <ol style="color:var(--text-secondary);padding-left:1.25rem">
      <li style="margin-bottom:0.5rem">
        Go to <strong>CF Administrator → Security → Sandbox Security</strong>
      </li>
      <li style="margin-bottom:0.5rem">
        Add the CF temp directory with <strong>Read</strong> permission:<br>
        <code style="background:var(--bg-card);padding:0.15rem 0.5rem;border-radius:3px;font-family:var(--font-mono);color:var(--color-gold);font-size:0.8rem">C:\ColdFusion2023\cfusion\runtime\work\Catalina\localhost\tmp\-</code>
        <br><span style="font-size:0.78rem;color:var(--text-muted)">(use <code>-</code> not <code>*</code> for recursive on Windows)</span>
      </li>
      <li style="margin-bottom:0.5rem">
        Add your upload folder with <strong>Read, Write</strong> permission:<br>
        <code style="background:var(--bg-card);padding:0.15rem 0.5rem;border-radius:3px;font-family:var(--font-mono);color:var(--color-gold);font-size:0.8rem">#htmlEditFormat(uploadDir)#-</code>
      </li>
      <li>Click <strong>Submit Changes</strong>, then try uploading again</li>
    </ol>
    <p style="color:var(--text-muted);font-size:0.8rem;margin-top:0.75rem">
      <strong>Quickest fix:</strong> In Sandbox Security, find the sandbox covering your webroot and either disable it
      or add both paths above. If you don't see a sandbox for your site, the restriction may be on the
      <em>default</em> sandbox — edit that one instead.
    </p>
  </div>
  </cfif>

  </cfoutput>
</cfcatch>
</cftry>
