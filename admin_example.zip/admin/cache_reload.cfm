<!--- admin/cache_reload.cfm --->
<cfinclude template="/includes/auth_check.cfm">

<cftry>
  <!--- Reload all settings from DB into application scope --->
  <cfquery name="getSettings" datasource="#application.dsn#">
    SELECT setting_key, setting_value FROM settings
  </cfquery>

  <cfset application.settings = {}>
  <cfloop query="getSettings">
    <cfset application.settings[setting_key] = setting_value>
  </cfloop>

  <cfif structKeyExists(application.settings, "active_theme")>
    <cfset application.theme    = application.settings.active_theme>
    <cfset application.themeURL = "#application.rootURL#/themes/#application.theme#">
  </cfif>

  <cfset session.flash = {type: "success", message: "Application cache reloaded successfully."}>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="cache_reload.cfm: #cfcatch.message#">
  <cfset session.flash = {type: "danger", message: "Cache reload failed: #cfcatch.message#"}>
</cfcatch>
</cftry>

<cflocation url="/admin/settings_general.cfm" addtoken="false">
