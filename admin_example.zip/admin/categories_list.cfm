<!--- admin/categories_list.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfset request.pageTitle = "Categories">

<cfquery name="getCategories" datasource="#application.dsn#">
  SELECT c.category_id, c.name, c.slug, c.description, c.image,
         c.sort_order, c.is_active,
         COUNT(p.product_id) AS product_count
  FROM categories c
  LEFT JOIN products p ON p.category_id = c.category_id AND p.is_active = 1
  GROUP BY c.category_id, c.name, c.slug, c.description, c.image, c.sort_order, c.is_active
  ORDER BY c.sort_order ASC, c.name ASC
</cfquery>

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div class="action-row">
  <div style="font-family:var(--font-heading);font-size:0.85rem;color:var(--text-muted)">#getCategories.recordCount# categories</div>
  <a href="/admin/categories_form.cfm" class="btn btn-fire btn-sm">
    <i class="bi bi-plus-lg"></i> Add Category
  </a>
</div>

<div id="cat-result"></div>

<div class="admin-card">
  <table class="admin-table">
    <thead>
      <tr>
        <th style="width:60px">Image</th>
        <th>Name</th>
        <th>Slug</th>
        <th>Products</th>
        <th>Sort</th>
        <th>Status</th>
        <th style="width:120px"></th>
      </tr>
    </thead>
    <tbody>
      <cfloop query="getCategories">
      <tr id="cat-row-#category_id#">
        <td>
          <cfif len(image)>
            <img src="#application.uploadURL#categories/#image#" alt="" style="width:40px;height:40px;object-fit:contain;background:var(--bg-elevated);border-radius:var(--border-radius);padding:4px">
          <cfelse>
            <div style="width:40px;height:40px;background:var(--bg-elevated);border-radius:var(--border-radius);display:flex;align-items:center;justify-content:center;opacity:0.3">🏷️</div>
          </cfif>
        </td>
        <td style="font-weight:600;color:var(--text-primary)">#htmlEditFormat(name)#</td>
        <td><span style="font-family:var(--font-mono);font-size:0.78rem;color:var(--text-muted)">#htmlEditFormat(slug)#</span></td>
        <td>
          <span style="font-family:var(--font-heading);font-weight:700;color:var(--color-fire)">#product_count#</span>
        </td>
        <td style="color:var(--text-muted)">#sort_order#</td>
        <td>
          <cfif is_active>
            <span class="status-badge status-active"><i class="bi bi-circle-fill" style="font-size:0.4rem"></i> Active</span>
          <cfelse>
            <span class="status-badge status-inactive">Inactive</span>
          </cfif>
        </td>
        <td>
          <div style="display:flex;gap:0.4rem">
            <a href="/admin/categories_form.cfm?category_id=#category_id#" class="btn btn-outline btn-sm">Edit</a>
            <button
              class="btn btn-sm"
              style="background:rgba(220,53,69,0.1);color:##f48995;border:1px solid rgba(220,53,69,0.2)"
              hx-post="/admin/categories_delete.cfm"
              hx-vals='{"category_id": "#category_id#"}'
              hx-target="##cat-row-#category_id#"
              hx-swap="outerHTML swap:300ms"
              hx-confirm="Delete '#htmlEditFormat(name)#'? Products in this category will be affected."
            >Del</button>
          </div>
        </td>
      </tr>
      </cfloop>
    </tbody>
  </table>
</div>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
