<!--- admin/categories_form.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="url.category_id" default="0">

<cfset isEdit = val(url.category_id) GT 0>
<cfset request.pageTitle = isEdit ? "Edit Category" : "Add Category">

<cfif isEdit>
  <cftry>
    <cfquery name="getRecord" datasource="#application.dsn#">
      SELECT * FROM categories
      WHERE category_id = <cfqueryparam value="#val(url.category_id)#" cfsqltype="cf_sql_integer">
    </cfquery>
    <cfif getRecord.recordCount EQ 0>
      <cflocation url="/admin/categories_list.cfm" addtoken="false">
    </cfif>
  <cfcatch type="any">
    <cflocation url="/admin/categories_list.cfm" addtoken="false">
  </cfcatch>
  </cftry>
</cfif>

<cfparam name="getRecord.category_id"  default="0">
<cfparam name="getRecord.name"         default="">
<cfparam name="getRecord.slug"         default="">
<cfparam name="getRecord.description"  default="">
<cfparam name="getRecord.image"        default="">
<cfparam name="getRecord.sort_order"   default="0">
<cfparam name="getRecord.is_active"    default="1">

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div style="margin-bottom:1.5rem">
  <a href="/admin/categories_list.cfm" style="font-size:0.8rem;color:var(--text-muted)">← Back to Categories</a>
</div>

<div id="form-messages"></div>

<form
  hx-post="/admin/categories_save.cfm"
  hx-target="##form-messages"
  hx-swap="innerHTML"
  hx-encoding="multipart/form-data"
  hx-indicator="##save-spinner"
>
  <input type="hidden" name="category_id" value="#getRecord.category_id#">

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:2rem;align-items:start">

    <div>
      <div class="admin-card">
        <div class="admin-card-header"><h3>Category Details</h3></div>
        <div class="admin-card-body">

          <div class="mb-3">
            <label class="form-label">Category Name *</label>
            <input type="text" name="name" class="form-control" value="#htmlEditFormat(getRecord.name)#" required
              hx-on:input="document.getElementById('slug-preview').value = this.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$$/g,'')">
          </div>

          <div class="mb-3">
            <label class="form-label">URL Slug *</label>
            <input type="text" id="slug-preview" name="slug" class="form-control"
              value="#htmlEditFormat(getRecord.slug)#" required
              style="font-family:var(--font-mono);font-size:0.85rem">
          </div>

          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="4">#htmlEditFormat(getRecord.description)#</textarea>
          </div>

        </div>
      </div>
    </div>

    <div>
      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Category Image</h3></div>
        <div class="admin-card-body">
          <div class="img-preview-wrap">
            <cfif len(getRecord.image)>
              <img id="cat-img-preview" src="#application.uploadURL#categories/#getRecord.image#" alt="">
            <cfelse>
              <img id="cat-img-preview" src="" alt="" style="display:none">
            </cfif>
          </div>
          <input type="file" name="image_file" class="form-control" accept="image/*"
            data-preview="cat-img-preview" style="font-size:0.8rem;padding:0.4rem;margin-top:0.5rem">
          <cfif len(getRecord.image)>
            <input type="hidden" name="existing_image" value="#getRecord.image#">
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">#getRecord.image#</div>
          </cfif>
        </div>
      </div>

      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Settings</h3></div>
        <div class="admin-card-body">

          <div class="mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="#getRecord.sort_order#" min="0">
          </div>

          <input type="hidden" name="is_active" value="0">
          <div class="form-check">
            <input type="checkbox" name="is_active" value="1" class="form-check-input" id="is_active"
              <cfif getRecord.is_active>checked</cfif>>
            <label class="form-check-label" for="is_active" style="color:var(--text-secondary);font-family:var(--font-heading)">Active</label>
          </div>

        </div>
      </div>

      <button type="submit" class="btn btn-fire" style="width:100%">
        <span id="save-spinner" class="htmx-indicator me-2" style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        <i class="bi bi-check-lg"></i>
        #isEdit ? "Update Category" : "Create Category"#
      </button>
    </div>

  </div>
</form>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
