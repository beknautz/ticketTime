<!--- admin/slides_save.cfm --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.slide_id"       default="0">
<cfparam name="form.headline"       default="">
<cfparam name="form.subtext"        default="">
<cfparam name="form.btn_text"       default="">
<cfparam name="form.btn_url"        default="">
<cfparam name="form.sort_order"     default="0">
<cfparam name="form.is_active"      default="0">
<cfparam name="form.existing_image" default="">

<cfif NOT len(trim(form.headline))>
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Headline is required.</div>
  <cfabort>
</cfif>

<!--- Image upload --->
<cfset savedImage = form.existing_image>
<cfset uploadDir  = expandPath("/assets/img/uploads/slides/")>
<cfif NOT directoryExists(uploadDir)>
  <cfdirectory action="create" directory="#uploadDir#">
</cfif>

<cftry>
  <cfif structKeyExists(form, "image_file") AND len(form.image_file)>
    <!--- No accept= — avoids CF2023 sandbox temp-file permission error --->
    <cffile action="upload" filefield="image_file"
      destination="#uploadDir#"
      nameconflict="makeunique">
    <cfif listFind("jpg,jpeg,png,gif,webp", lCase(cffile.serverFileExt))>
      <cfset savedImage = cffile.serverFile>
    <cfelse>
      <cftry>
        <cffile action="delete" file="#uploadDir##cffile.serverFile#">
      <cfcatch type="any"></cfcatch>
      </cftry>
    </cfif>
  </cfif>
<cfcatch type="any"><!--- no file uploaded --->
</cfcatch>
</cftry>

<cftry>
  <cfif val(form.slide_id)>
    <cfquery datasource="#application.dsn#">
      UPDATE slides SET
        headline   = <cfqueryparam value="#trim(form.headline)#"  cfsqltype="cf_sql_varchar">,
        subtext    = <cfqueryparam value="#trim(form.subtext)#"   cfsqltype="cf_sql_varchar">,
        btn_text   = <cfqueryparam value="#trim(form.btn_text)#"  cfsqltype="cf_sql_varchar">,
        btn_url    = <cfqueryparam value="#trim(form.btn_url)#"   cfsqltype="cf_sql_varchar">,
        image      = <cfqueryparam value="#savedImage#"           cfsqltype="cf_sql_varchar">,
        sort_order = <cfqueryparam value="#val(form.sort_order)#" cfsqltype="cf_sql_integer">,
        is_active  = <cfqueryparam value="#form.is_active#"       cfsqltype="cf_sql_bit">
      WHERE slide_id = <cfqueryparam value="#val(form.slide_id)#" cfsqltype="cf_sql_integer">
    </cfquery>
  <cfelse>
    <cfquery datasource="#application.dsn#">
      INSERT INTO slides (headline, subtext, btn_text, btn_url, image, sort_order, is_active, created_at)
      VALUES (
        <cfqueryparam value="#trim(form.headline)#"  cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.subtext)#"   cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.btn_text)#"  cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.btn_url)#"   cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#savedImage#"           cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#val(form.sort_order)#" cfsqltype="cf_sql_integer">,
        <cfqueryparam value="#form.is_active#"       cfsqltype="cf_sql_bit">,
        NOW()
      )
    </cfquery>
  </cfif>

  <div class="flash flash-success">
    <i class="bi bi-check-circle-fill"></i>
    Slide saved. <a href="/admin/settings_home.cfm" style="color:var(--color-gold)">← Back to Homepage</a>
  </div>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="slides_save.cfm: #cfcatch.message#">
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Error saving slide.</div>
</cfcatch>
</cftry>
