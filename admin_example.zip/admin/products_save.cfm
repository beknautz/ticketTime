<!--- admin/products_save.cfm --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.product_id"  default="0">
<cfparam name="form.category_id" default="0">
<cfparam name="form.name"        default="">
<cfparam name="form.slug"        default="">
<cfparam name="form.description" default="">
<cfparam name="form.sku"         default="">
<cfparam name="form.price"       default="0">
<cfparam name="form.tag"         default="">
<cfparam name="form.is_active"   default="0">
<cfparam name="form.is_featured" default="0">
<cfparam name="form.is_new"      default="0">
<cfparam name="form.sort_order"  default="0">

<!---
  Checkboxes submit as "0,1" when checked (hidden field + checkbox both fire).
  listLast() grabs the final value: 1 if checked, 0 if only hidden field sent.
--->
<cfset isActive   = val(listLast(form.is_active))>
<cfset isFeatured = val(listLast(form.is_featured))>
<cfset isNew      = val(listLast(form.is_new))>

<!--- Validate --->
<cfset errors = []>
<cfif NOT len(trim(form.name))>
  <cfset arrayAppend(errors, "Product name is required.")>
</cfif>
<cfif NOT len(trim(form.slug))>
  <cfset arrayAppend(errors, "Slug is required.")>
</cfif>
<cfif NOT val(form.category_id)>
  <cfset arrayAppend(errors, "Category is required.")>
</cfif>
<cfif len(trim(form.slug)) AND NOT reFind("^[a-z0-9\-]+$", lCase(trim(form.slug)))>
  <cfset arrayAppend(errors, "Slug: lowercase letters, numbers and hyphens only.")>
</cfif>

<cfif arrayLen(errors)>
  <cfoutput>
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    <span><cfloop array="#errors#" item="local.e">#local.e# </cfloop></span>
  </div>
  </cfoutput>
  <cfabort>
</cfif>

<cftry>

  <cfif val(form.product_id)>

    <!--- UPDATE --->
    <cfquery datasource="#application.dsn#">
      UPDATE products SET
        category_id = <cfqueryparam value="#val(form.category_id)#"  cfsqltype="cf_sql_integer">,
        name        = <cfqueryparam value="#trim(form.name)#"        cfsqltype="cf_sql_varchar">,
        slug        = <cfqueryparam value="#lCase(trim(form.slug))#" cfsqltype="cf_sql_varchar">,
        description = <cfqueryparam value="#trim(form.description)#" cfsqltype="cf_sql_varchar">,
        sku         = <cfqueryparam value="#trim(form.sku)#"         cfsqltype="cf_sql_varchar">,
        price       = <cfqueryparam value="#val(form.price)#"        cfsqltype="cf_sql_decimal">,
        tag         = <cfqueryparam value="#trim(form.tag)#"         cfsqltype="cf_sql_varchar">,
        is_active   = <cfqueryparam value="#isActive#"               cfsqltype="cf_sql_bit">,
        is_featured = <cfqueryparam value="#isFeatured#"             cfsqltype="cf_sql_bit">,
        is_new      = <cfqueryparam value="#isNew#"                  cfsqltype="cf_sql_bit">,
        sort_order  = <cfqueryparam value="#val(form.sort_order)#"   cfsqltype="cf_sql_integer">,
        updated_at  = NOW()
      WHERE product_id = <cfqueryparam value="#val(form.product_id)#" cfsqltype="cf_sql_integer">
    </cfquery>

    <div class="flash flash-success">
      <i class="bi bi-check-circle-fill"></i>
      Product "<cfoutput>#htmlEditFormat(trim(form.name))#</cfoutput>" updated.
      <a href="/product.cfm?slug=<cfoutput>#lCase(trim(form.slug))#</cfoutput>"
         target="_blank" style="color:var(--color-gold);margin-left:0.5rem">View on Site &rarr;</a>
    </div>

  <cfelse>

    <!--- INSERT --->
    <cfquery datasource="#application.dsn#" result="insertResult">
      INSERT INTO products
        (category_id, name, slug, description, sku, price,
         image, image2, image3, tag,
         is_active, is_featured, is_new, sort_order,
         created_at, updated_at)
      VALUES (
        <cfqueryparam value="#val(form.category_id)#"  cfsqltype="cf_sql_integer">,
        <cfqueryparam value="#trim(form.name)#"        cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#lCase(trim(form.slug))#" cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.description)#" cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.sku)#"         cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#val(form.price)#"        cfsqltype="cf_sql_decimal">,
        '', '', '',
        <cfqueryparam value="#trim(form.tag)#"         cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#isActive#"               cfsqltype="cf_sql_bit">,
        <cfqueryparam value="#isFeatured#"             cfsqltype="cf_sql_bit">,
        <cfqueryparam value="#isNew#"                  cfsqltype="cf_sql_bit">,
        <cfqueryparam value="#val(form.sort_order)#"   cfsqltype="cf_sql_integer">,
        NOW(), NOW()
      )
    </cfquery>

    <div class="flash flash-success">
      <i class="bi bi-check-circle-fill"></i>
      Product "<cfoutput>#htmlEditFormat(trim(form.name))#</cfoutput>" created.
      <a href="/admin/products_form.cfm?product_id=<cfoutput>#insertResult.generatedKey#</cfoutput>"
         style="color:var(--color-gold);margin-left:0.5rem">Edit &amp; add images &rarr;</a>
    </div>

  </cfif>

<cfcatch type="database">
  <cflog file="nativepyro_errors" text="products_save DB: #cfcatch.message# | #cfcatch.detail#">
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    Database error: <cfoutput>#htmlEditFormat(cfcatch.message)#</cfoutput>
    <cfif findNoCase("Duplicate", cfcatch.message)> &mdash; That slug is already in use.</cfif>
  </div>
</cfcatch>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="products_save error: #cfcatch.message# | #cfcatch.detail#">
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    Error: <cfoutput>#htmlEditFormat(cfcatch.message)#</cfoutput>
  </div>
</cfcatch>

</cftry>
