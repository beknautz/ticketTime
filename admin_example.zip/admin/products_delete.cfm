<!--- admin/products_delete.cfm — HTMX POST handler --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="form.product_id" default="0">

<cfif NOT val(form.product_id)>
  <cfabort>
</cfif>

<cftry>
  <cfquery datasource="#application.dsn#">
    DELETE FROM products
    WHERE product_id = <cfqueryparam value="#val(form.product_id)#" cfsqltype="cf_sql_integer">
  </cfquery>
  <!--- Return empty — HTMX outerHTML swap removes the row --->
<cfcatch type="database">
  <cflog file="nativepyro_errors" text="products_delete.cfm error: #cfcatch.message#">
  <!--- Return a visible error row --->
  <tr><td colspan="8" style="color:##f48995;padding:0.75rem 1rem">Delete failed. This product may be in use.</td></tr>
</cfcatch>
</cftry>
