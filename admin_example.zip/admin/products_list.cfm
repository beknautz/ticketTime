<!--- admin/products_list.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="url.category" default="">
<cfparam name="url.page"     default="1">

<cfset request.pageTitle = "Products">

<cfset perPage     = 30>
<cfset currentPage = max(1, int(val(url.page)))>
<cfset offset      = (currentPage - 1) * perPage>
<cfset filterCat   = trim(url.category)>

<cfquery name="getTotal" datasource="#application.dsn#">
  SELECT COUNT(*) AS total FROM products p
  JOIN categories c ON c.category_id = p.category_id
  WHERE 1=1
  <cfif len(filterCat)>
    AND c.slug = <cfqueryparam value="#filterCat#" cfsqltype="cf_sql_varchar">
  </cfif>
</cfquery>

<cfset totalPages = max(1, ceiling(getTotal.total / perPage))>

<cfquery name="getProducts" datasource="#application.dsn#">
  SELECT p.product_id, p.name, p.slug, p.price, p.image, p.tag,
         p.is_active, p.is_featured, p.is_new, p.sku,
         c.name AS category_name, c.slug AS category_slug
  FROM products p
  JOIN categories c ON c.category_id = p.category_id
  WHERE 1=1
  <cfif len(filterCat)>
    AND c.slug = <cfqueryparam value="#filterCat#" cfsqltype="cf_sql_varchar">
  </cfif>
  ORDER BY c.sort_order ASC, p.sort_order ASC, p.name ASC
  LIMIT <cfqueryparam value="#perPage#" cfsqltype="cf_sql_integer">
  OFFSET <cfqueryparam value="#offset#" cfsqltype="cf_sql_integer">
</cfquery>

<cfquery name="getCategories" datasource="#application.dsn#">
  SELECT category_id, name, slug FROM categories WHERE is_active = 1 ORDER BY sort_order ASC
</cfquery>

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div class="action-row">
  <div style="display:flex;align-items:center;gap:1rem">
    <div style="font-family:var(--font-heading);font-size:0.85rem;color:var(--text-muted)">#getTotal.total# products</div>

    <!--- Category filter --->
    <select
      onchange="window.location='/admin/products_list.cfm?category='+this.value"
      style="background:var(--bg-card);border:1px solid var(--border-color);color:var(--text-primary);padding:0.4rem 0.75rem;border-radius:var(--border-radius);font-size:0.85rem;cursor:pointer;outline:none"
    >
      <option value="">All Categories</option>
      <cfloop query="getCategories">
      <option value="#slug#" <cfif filterCat EQ slug>selected</cfif>>#htmlEditFormat(name)#</option>
      </cfloop>
    </select>

    <!--- HTMX Search --->
    <input
      type="search"
      placeholder="Search products..."
      hx-post="/admin/products_search.cfm"
      hx-trigger="keyup changed delay:300ms, search"
      hx-target="##products-tbody"
      hx-swap="innerHTML"
      style="background:var(--bg-card);border:1px solid var(--border-color);color:var(--text-primary);padding:0.4rem 0.875rem;border-radius:var(--border-radius);font-size:0.85rem;outline:none;width:220px"
    >
  </div>

  <a href="/admin/products_form.cfm" class="btn btn-fire btn-sm">
    <i class="bi bi-plus-lg"></i> Add Product
  </a>
</div>

<div class="admin-card">
  <table class="admin-table">
    <thead>
      <tr>
        <th style="width:60px">Image</th>
        <th>Name</th>
        <th>Category</th>
        <th>SKU</th>
        <th>Price</th>
        <th>Flags</th>
        <th>Status</th>
        <th style="width:100px"></th>
      </tr>
    </thead>
    <tbody id="products-tbody">
      <cfinclude template="/admin/includes/products_rows.cfm">
    </tbody>
  </table>
</div>

<!--- Pagination --->
<cfif totalPages GT 1>
<nav class="pagination">
  <a href="?category=#filterCat#&page=#max(1, currentPage-1)#" class="page-link <cfif currentPage EQ 1>disabled</cfif>"><i class="bi bi-chevron-left"></i></a>
  <cfloop from="1" to="#totalPages#" index="local.p">
    <a href="?category=#filterCat#&page=#local.p#" class="page-link <cfif local.p EQ currentPage>active</cfif>">#local.p#</a>
  </cfloop>
  <a href="?category=#filterCat#&page=#min(totalPages, currentPage+1)#" class="page-link <cfif currentPage EQ totalPages>disabled</cfif>"><i class="bi bi-chevron-right"></i></a>
</nav>
</cfif>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
