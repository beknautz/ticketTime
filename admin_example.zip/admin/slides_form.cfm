<!--- admin/slides_form.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="url.slide_id" default="0">

<cfset isEdit = val(url.slide_id) GT 0>
<cfset request.pageTitle = isEdit ? "Edit Slide" : "Add Slide">

<cfif isEdit>
  <cftry>
    <cfquery name="getRecord" datasource="#application.dsn#">
      SELECT * FROM slides
      WHERE slide_id = <cfqueryparam value="#val(url.slide_id)#" cfsqltype="cf_sql_integer">
    </cfquery>
    <cfif getRecord.recordCount EQ 0>
      <cflocation url="/admin/settings_home.cfm" addtoken="false">
    </cfif>
  <cfcatch type="any">
    <cflocation url="/admin/settings_home.cfm" addtoken="false">
  </cfcatch>
  </cftry>
</cfif>

<cfparam name="getRecord.slide_id"   default="0">
<cfparam name="getRecord.headline"   default="">
<cfparam name="getRecord.subtext"    default="">
<cfparam name="getRecord.btn_text"   default="">
<cfparam name="getRecord.btn_url"    default="">
<cfparam name="getRecord.image"      default="">
<cfparam name="getRecord.sort_order" default="0">
<cfparam name="getRecord.is_active"  default="1">

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div style="margin-bottom:1.5rem">
  <a href="/admin/settings_home.cfm" style="font-size:0.8rem;color:var(--text-muted)">← Back to Homepage Settings</a>
</div>

<div id="form-messages"></div>

<form
  hx-post="/admin/slides_save.cfm"
  hx-target="##form-messages"
  hx-swap="innerHTML"
  hx-encoding="multipart/form-data"
  hx-indicator="##save-spinner"
>
  <input type="hidden" name="slide_id" value="#getRecord.slide_id#">

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:2rem;align-items:start">

    <div>
      <div class="admin-card">
        <div class="admin-card-header"><h3>Slide Content</h3></div>
        <div class="admin-card-body">

          <div class="mb-3">
            <label class="form-label">Headline *</label>
            <input type="text" name="headline" class="form-control" value="#htmlEditFormat(getRecord.headline)#" required placeholder="Ignite the Night">
          </div>

          <div class="mb-3">
            <label class="form-label">Subtext</label>
            <textarea name="subtext" class="form-control" rows="3" placeholder="Supporting text below the headline...">#htmlEditFormat(getRecord.subtext)#</textarea>
          </div>

          <div class="row">
            <div>
              <label class="form-label">Button Text</label>
              <input type="text" name="btn_text" class="form-control" value="#htmlEditFormat(getRecord.btn_text)#" placeholder="Browse Catalog">
            </div>
            <div>
              <label class="form-label">Button URL</label>
              <input type="text" name="btn_url" class="form-control" value="#htmlEditFormat(getRecord.btn_url)#" placeholder="/catalog.cfm">
            </div>
          </div>

        </div>
      </div>
    </div>

    <div>
      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Slide Image</h3></div>
        <div class="admin-card-body">
          <div class="img-preview-wrap" style="width:100%;height:120px">
            <cfif len(getRecord.image)>
              <img id="slide-img-preview" src="#application.uploadURL#slides/#getRecord.image#" alt="" style="width:100%;height:100%;object-fit:cover">
            <cfelse>
              <img id="slide-img-preview" src="" alt="" style="display:none">
            </cfif>
          </div>
          <input type="file" name="image_file" class="form-control" accept="image/*"
            data-preview="slide-img-preview" style="font-size:0.8rem;padding:0.4rem;margin-top:0.5rem">
          <cfif len(getRecord.image)>
            <input type="hidden" name="existing_image" value="#getRecord.image#">
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.25rem">#getRecord.image#</div>
          <cfelse>
            <cfparam name="form.existing_image" default="">
          </cfif>
        </div>
      </div>

      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Settings</h3></div>
        <div class="admin-card-body">
          <div class="mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="#getRecord.sort_order#" min="0">
          </div>
          <input type="hidden" name="is_active" value="0">
          <div class="form-check">
            <input type="checkbox" name="is_active" value="1" class="form-check-input" id="is_active"
              <cfif getRecord.is_active>checked</cfif>>
            <label class="form-check-label" for="is_active" style="color:var(--text-secondary);font-family:var(--font-heading)">Active</label>
          </div>
        </div>
      </div>

      <button type="submit" class="btn btn-fire" style="width:100%">
        <span id="save-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        <i class="bi bi-check-lg"></i>
        #isEdit ? "Update Slide" : "Create Slide"#
      </button>
    </div>

  </div>
</form>

<style>@keyframes spin { to { transform: rotate(360deg); } }</style>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
