<!--- admin/hero_image_remove.cfm — Remove hero background image --->
<cfinclude template="/includes/auth_check.cfm">

<cftry>
  <!--- Delete file from disk --->
  <cfif structKeyExists(application.settings, "hero_image") AND len(trim(application.settings.hero_image))>
    <cfset oldFile = expandPath("/assets/img/uploads/hero/") & application.settings.hero_image>
    <cfif fileExists(oldFile)>
      <cftry>
        <cffile action="delete" file="#oldFile#">
      <cfcatch type="any"><!--- ignore --->
      </cfcatch>
      </cftry>
    </cfif>
  </cfif>

  <!--- Clear in settings table --->
  <cfquery datasource="#application.dsn#">
    INSERT INTO settings (setting_key, setting_value)
    VALUES (
      <cfqueryparam value="hero_image" cfsqltype="cf_sql_varchar">,
      <cfqueryparam value="" cfsqltype="cf_sql_varchar">
    )
    ON DUPLICATE KEY UPDATE
      setting_value = <cfqueryparam value="" cfsqltype="cf_sql_varchar">
  </cfquery>

  <!--- Clear application scope --->
  <cfset application.settings.hero_image = "">

  <div class="flash flash-success">
    <i class="bi bi-check-circle-fill"></i>
    Hero image removed. The gradient background is now active.
  </div>
  <div style="width:100%;max-width:600px;height:100px;background:var(--bg-elevated);border:1px dashed var(--border-color);border-radius:var(--border-radius-lg);display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem">
    <span style="font-size:1.5rem;opacity:0.3">🖼️</span>
    <span style="font-size:0.8rem;color:var(--text-muted)">No hero image — gradient background active</span>
  </div>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="hero_image_remove.cfm error: #cfcatch.message#">
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    Error removing image. Please try again.
  </div>
</cfcatch>
</cftry>
