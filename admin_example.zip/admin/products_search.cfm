<!--- admin/products_search.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="form.q" default="">

<cfset searchQ = trim(form.q)>

<cftry>
  <cfquery name="getProducts" datasource="#application.dsn#">
    SELECT p.product_id, p.name, p.slug, p.price, p.image, p.tag,
           p.is_active, p.is_featured, p.is_new, p.sku,
           c.name AS category_name, c.slug AS category_slug
    FROM products p
    JOIN categories c ON c.category_id = p.category_id
    WHERE 1=1
    <cfif len(searchQ)>
      AND (p.name LIKE <cfqueryparam value="%%#searchQ#%%" cfsqltype="cf_sql_varchar">
        OR p.sku LIKE <cfqueryparam value="%%#searchQ#%%" cfsqltype="cf_sql_varchar">
        OR c.name LIKE <cfqueryparam value="%%#searchQ#%%" cfsqltype="cf_sql_varchar">)
    </cfif>
    ORDER BY p.name ASC
    LIMIT 100
  </cfquery>

  <cfinclude template="/admin/includes/products_rows.cfm">

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="products_search.cfm: #cfcatch.message#">
  <tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:2rem">Search error.</td></tr>
</cfcatch>
</cftry>
