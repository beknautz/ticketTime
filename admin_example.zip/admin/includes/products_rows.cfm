<!--- admin/includes/products_rows.cfm — shared by list and HTMX search --->
<cfif NOT isDefined("getProducts") OR getProducts.recordCount EQ 0>
  <tr>
    <td colspan="8" style="text-align:center;padding:3rem;color:var(--text-muted)">No products found.</td>
  </tr>
<cfelse>
  <cfoutput query="getProducts">
  <tr id="prod-row-#product_id#">
    <td>
      <cfif len(image)>
        <img src="#application.uploadURL#products/#image#" alt="">
      <cfelse>
        <div style="width:48px;height:48px;background:var(--bg-elevated);border-radius:var(--border-radius);display:flex;align-items:center;justify-content:center;font-size:1.25rem;opacity:0.3">🎆</div>
      </cfif>
    </td>
    <td>
      <div style="font-weight:600;color:var(--text-primary)">#htmlEditFormat(name)#</div>
      <cfif len(tag)><span class="product-badge badge-#lCase(tag)#" style="position:static;margin-top:0.25rem">#tag#</span></cfif>
    </td>
    <td>#htmlEditFormat(category_name)#</td>
    <td><span style="font-family:var(--font-mono);font-size:0.75rem">#htmlEditFormat(sku)#</span></td>
    <td>
      <cfif price GT 0>$#numberFormat(price, ",.00")#<cfelse><span style="color:var(--text-muted)">—</span></cfif>
    </td>
    <td>
      <div style="display:flex;gap:0.3rem;flex-wrap:wrap">
        <cfif is_featured><span class="status-badge status-featured">★ Featured</span></cfif>
        <cfif is_new><span class="status-badge" style="background:rgba(255,69,0,0.12);color:var(--color-fire)">New</span></cfif>
      </div>
    </td>
    <td>
      <cfif is_active>
        <span class="status-badge status-active"><i class="bi bi-circle-fill" style="font-size:0.4rem"></i> Active</span>
      <cfelse>
        <span class="status-badge status-inactive">Inactive</span>
      </cfif>
    </td>
    <td>
      <div style="display:flex;gap:0.4rem">
        <a href="/admin/products_form.cfm?product_id=#product_id#" class="btn btn-outline btn-sm">Edit</a>
        <button
          class="btn btn-sm"
          style="background:rgba(220,53,69,0.1);color:##f48995;border:1px solid rgba(220,53,69,0.2)"
          hx-post="/admin/products_delete.cfm"
          hx-vals='{"product_id": "#product_id#"}'
          hx-target="##prod-row-#product_id#"
          hx-swap="outerHTML swap:300ms"
          hx-confirm="Delete '#htmlEditFormat(name)#'? This cannot be undone."
        >Del</button>
      </div>
    </td>
  </tr>
  </cfoutput>
</cfif>
