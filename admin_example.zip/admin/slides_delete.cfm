<!--- admin/slides_delete.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="form.slide_id" default="0">

<cfif NOT val(form.slide_id)><cfabort></cfif>

<cftry>
  <cfquery datasource="#application.dsn#">
    DELETE FROM slides
    WHERE slide_id = <cfqueryparam value="#val(form.slide_id)#" cfsqltype="cf_sql_integer">
  </cfquery>
<cfcatch type="any">
  <cflog file="nativepyro_errors" text="slides_delete.cfm: #cfcatch.message#">
  <tr id="slide-row-<cfoutput>#val(form.slide_id)#</cfoutput>">
    <td colspan="5" style="color:##f48995;padding:0.75rem">Delete failed.</td>
  </tr>
</cfcatch>
</cftry>
