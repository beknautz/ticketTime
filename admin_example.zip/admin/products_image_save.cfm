<!--- admin/products_image_save.cfm --->
<!--- Dedicated image-only upload handler for a single product image slot. --->
<!--- Called by the individual image upload forms on products_form.cfm.    --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.product_id"    default="0">
<cfparam name="form.image_slot"    default="1">
<cfparam name="form.existing_image" default="">

<cfif NOT val(form.product_id)>
  <span style="color:var(--text-muted);font-size:0.8rem">No product ID.</span>
  <cfabort>
</cfif>

<cfset uploadDir   = expandPath("/assets/img/uploads/products/")>
<cfset allowedExts = "jpg,jpeg,png,gif,webp">
<cfset slot        = val(form.image_slot)>

<!--- Map slot number to DB column name --->
<cfif slot EQ 2>
  <cfset colName = "image2">
<cfelseif slot EQ 3>
  <cfset colName = "image3">
<cfelse>
  <cfset colName = "image">
  <cfset slot    = 1>
</cfif>

<cftry>

  <!--- Upload the file (no accept= to avoid sandbox FilePermission error) --->
  <cffile action="upload"
          filefield="image_file"
          destination="#uploadDir#"
          nameconflict="makeunique">

  <!--- Validate extension --->
  <cfif NOT listFind(allowedExts, lCase(cffile.serverFileExt))>
    <cftry><cffile action="delete" file="#uploadDir##cffile.serverFile#"><cfcatch></cfcatch></cftry>
    <cfoutput>
    <span style="color:##f48995;font-size:0.8rem">
      <i class="bi bi-exclamation-circle-fill"></i>
      Invalid type. Use JPG, PNG, GIF or WEBP.
    </span>
    </cfoutput>
    <cfabort>
  </cfif>

  <cfset savedFilename = cffile.serverFile>

  <!--- Save filename to the correct image column --->
  <cfquery datasource="#application.dsn#">
    UPDATE products
    SET #colName# = <cfqueryparam value="#savedFilename#" cfsqltype="cf_sql_varchar">,
        updated_at = NOW()
    WHERE product_id = <cfqueryparam value="#val(form.product_id)#" cfsqltype="cf_sql_integer">
  </cfquery>

  <!--- Return inline confirmation + filename display --->
  <cfoutput>
  <span style="color:##75c99a;font-size:0.78rem">
    <i class="bi bi-check-circle-fill"></i> #htmlEditFormat(savedFilename)#
  </span>
  <!--- Update the preview image via JS --->
  <script>
    (function(){
      var img = document.getElementById('img#slot#-preview');
      if (img) {
        img.src = '#application.uploadURL#products/#savedFilename#?' + Date.now();
        img.style.display = 'block';
      }
    })();
  </script>
  </cfoutput>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="products_image_save slot #form.image_slot#: #cfcatch.message#">
  <cfoutput>
  <span style="color:##f48995;font-size:0.8rem">
    <i class="bi bi-exclamation-circle-fill"></i>
    Upload failed: #htmlEditFormat(cfcatch.message)#
  </span>
  </cfoutput>
</cfcatch>
</cftry>
