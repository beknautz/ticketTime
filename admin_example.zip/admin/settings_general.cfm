<!--- admin/settings_general.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfset request.pageTitle = "General Settings">

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div id="settings-result" style="margin-bottom:1rem"></div>

<!--- ============================================================
  SITE IDENTITY
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>🏷️ Site Identity</h3>
  </div>
  <div class="admin-card-body">
    <form
      hx-post="/admin/settings_save.cfm"
      hx-target="##settings-result"
      hx-swap="innerHTML"
      hx-indicator="##identity-spinner"
    >
      <input type="hidden" name="section" value="identity">

      <div class="row" style="margin-bottom:1rem">
        <div>
          <label class="form-label">Site Name</label>
          <input type="text" name="site_name" class="form-control"
            value="#htmlEditFormat(application.settings.site_name)#">
        </div>
        <div>
          <label class="form-label">Site Tagline</label>
          <input type="text" name="site_tagline" class="form-control"
            value="#htmlEditFormat(application.settings.site_tagline)#">
        </div>
      </div>

      <div style="margin-bottom:1rem">
        <label class="form-label">Meta Description (SEO)</label>
        <textarea name="meta_description" class="form-control" rows="3">#htmlEditFormat(application.settings.meta_description)#</textarea>
      </div>

      <div style="margin-bottom:1rem">
        <label class="form-label">Footer Text</label>
        <input type="text" name="footer_text" class="form-control"
          value="#htmlEditFormat(application.settings.footer_text)#">
      </div>

      <button type="submit" class="btn btn-fire btn-sm">
        <span id="identity-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        Save Identity
      </button>
    </form>
  </div>
</div>

<!--- ============================================================
  CONTACT INFORMATION
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>📞 Contact Information</h3>
    <span style="font-size:0.75rem;color:var(--text-muted)">Shown in footer and contact page</span>
  </div>
  <div class="admin-card-body">
    <form
      hx-post="/admin/settings_save.cfm"
      hx-target="##settings-result"
      hx-swap="innerHTML"
      hx-indicator="##contact-spinner"
    >
      <input type="hidden" name="section" value="contact">

      <div class="row" style="margin-bottom:1rem">
        <div>
          <label class="form-label">Phone Number</label>
          <input type="text" name="site_phone" class="form-control"
            value="#htmlEditFormat(application.settings.site_phone)#"
            placeholder="1-800-PYRO-NOW">
        </div>
        <div>
          <label class="form-label">Email Address</label>
          <input type="email" name="site_email" class="form-control"
            value="#htmlEditFormat(application.settings.site_email)#"
            placeholder="info@nativepyro.com">
        </div>
      </div>

      <div style="margin-bottom:1rem">
        <label class="form-label">Address / Location</label>
        <input type="text" name="site_address" class="form-control"
          value="#htmlEditFormat(application.settings.site_address)#"
          placeholder="Minnesota Iron Range, USA">
      </div>

      <button type="submit" class="btn btn-fire btn-sm">
        <span id="contact-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        Save Contact Info
      </button>
    </form>
  </div>
</div>

<!--- ============================================================
  CHANGE PASSWORD
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>🔐 Change Password</h3>
  </div>
  <div class="admin-card-body">
    <form
      hx-post="/admin/password_save.cfm"
      hx-target="##settings-result"
      hx-swap="innerHTML"
      hx-indicator="##pw-spinner"
    >
      <div class="row" style="margin-bottom:1rem">
        <div>
          <label class="form-label">Current Password</label>
          <input type="password" name="current_password" class="form-control" placeholder="••••••••">
        </div>
        <div>
          <label class="form-label">New Password</label>
          <input type="password" name="new_password" class="form-control" placeholder="••••••••" minlength="8">
        </div>
      </div>

      <button type="submit" class="btn btn-outline btn-sm">
        <span id="pw-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        Update Password
      </button>
    </form>
  </div>
</div>

<!--- ============================================================
  CACHE / RELOAD
  ============================================================ --->
<div class="admin-card">
  <div class="admin-card-header">
    <h3>⚡ Application Cache</h3>
  </div>
  <div class="admin-card-body">
    <p style="color:var(--text-secondary);font-size:0.9rem;margin-bottom:1rem">
      Settings are cached in application scope. If changes aren't showing on the site, reload the cache.
    </p>
    <a
      href="/admin/cache_reload.cfm"
      class="btn btn-outline btn-sm"
      onclick="return confirm('Reload application cache?')"
    >
      <i class="bi bi-arrow-clockwise"></i> Reload Cache
    </a>
  </div>
</div>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
