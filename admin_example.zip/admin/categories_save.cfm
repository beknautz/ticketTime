<!--- admin/categories_save.cfm --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.category_id"    default="0">
<cfparam name="form.name"           default="">
<cfparam name="form.slug"           default="">
<cfparam name="form.description"    default="">
<cfparam name="form.sort_order"     default="0">
<cfparam name="form.is_active"      default="0">
<cfparam name="form.existing_image" default="">

<cfset errors = []>
<cfif NOT len(trim(form.name))> <cfset arrayAppend(errors, "Name is required.")></cfif>
<cfif NOT len(trim(form.slug))> <cfset arrayAppend(errors, "Slug is required.")></cfif>
<cfif len(form.slug) AND NOT reFind("^[a-z0-9\-]+$", lCase(trim(form.slug)))>
  <cfset arrayAppend(errors, "Slug: lowercase letters, numbers, hyphens only.")>
</cfif>

<cfif arrayLen(errors)>
  <cfoutput>
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    <span><cfloop array="#errors#" item="local.e">#local.e# </cfloop></span>
  </div>
  </cfoutput>
  <cfabort>
</cfif>

<!--- Image upload --->
<cfset savedImage = form.existing_image>
<cfset uploadDir  = expandPath("/assets/img/uploads/categories/")>

<cftry>
  <cfif structKeyExists(form, "image_file") AND len(form.image_file)>
    <!--- No accept= — avoids CF2023 sandbox temp-file permission error --->
    <cffile action="upload" filefield="image_file"
      destination="#uploadDir#"
      nameconflict="makeunique">
    <!--- Validate extension; reject non-images silently --->
    <cfif listFind("jpg,jpeg,png,gif,webp", lCase(cffile.serverFileExt))>
      <cfset savedImage = cffile.serverFile>
    <cfelse>
      <cftry>
        <cffile action="delete" file="#uploadDir##cffile.serverFile#">
      <cfcatch type="any"></cfcatch>
      </cftry>
    </cfif>
  </cfif>
<cfcatch type="any"><!--- No file uploaded or error — keep existing --->
</cfcatch>
</cftry>

<cftry>
  <cfif val(form.category_id)>
    <cfquery datasource="#application.dsn#">
      UPDATE categories SET
        name        = <cfqueryparam value="#trim(form.name)#"        cfsqltype="cf_sql_varchar">,
        slug        = <cfqueryparam value="#lCase(trim(form.slug))#" cfsqltype="cf_sql_varchar">,
        description = <cfqueryparam value="#trim(form.description)#" cfsqltype="cf_sql_varchar">,
        image       = <cfqueryparam value="#savedImage#"             cfsqltype="cf_sql_varchar">,
        sort_order  = <cfqueryparam value="#val(form.sort_order)#"   cfsqltype="cf_sql_integer">,
        is_active   = <cfqueryparam value="#form.is_active#"         cfsqltype="cf_sql_bit">,
        updated_at  = NOW()
      WHERE category_id = <cfqueryparam value="#val(form.category_id)#" cfsqltype="cf_sql_integer">
    </cfquery>
    <div class="flash flash-success">
      <i class="bi bi-check-circle-fill"></i>
      Category "<cfoutput>#htmlEditFormat(trim(form.name))#</cfoutput>" updated.
    </div>
  <cfelse>
    <cfquery datasource="#application.dsn#" result="insertResult">
      INSERT INTO categories (name, slug, description, image, sort_order, is_active, created_at, updated_at)
      VALUES (
        <cfqueryparam value="#trim(form.name)#"        cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#lCase(trim(form.slug))#" cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form.description)#" cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#savedImage#"             cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#val(form.sort_order)#"   cfsqltype="cf_sql_integer">,
        <cfqueryparam value="#form.is_active#"         cfsqltype="cf_sql_bit">,
        NOW(), NOW()
      )
    </cfquery>
    <div class="flash flash-success">
      <i class="bi bi-check-circle-fill"></i>
      Category "<cfoutput>#htmlEditFormat(trim(form.name))#</cfoutput>" created.
      <a href="/admin/categories_form.cfm?category_id=<cfoutput>#insertResult.generatedKey#</cfoutput>" style="color:var(--color-gold);margin-left:0.5rem">Edit it →</a>
    </div>
  </cfif>

<cfcatch type="database">
  <cflog file="nativepyro_errors" text="categories_save.cfm: #cfcatch.message#">
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    Database error: <cfoutput>#htmlEditFormat(cfcatch.message)#</cfoutput>
    <cfif findNoCase("Duplicate", cfcatch.message)> — That slug is already in use.</cfif>
  </div>
</cfcatch>
</cftry>
