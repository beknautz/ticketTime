<!--- admin/settings_save.cfm — Universal settings POST handler --->
<cfinclude template="/includes/auth_check.cfm">

<cfparam name="form.section" default="">

<!--- Map section to fields --->
<cfset fieldMap = {
  "hero"     = "hero_headline,hero_subheadline,hero_btn_text",
  "about"    = "about_headline,about_text",
  "identity" = "site_name,site_tagline,meta_description,footer_text",
  "contact"  = "site_phone,site_email,site_address"
}>

<cfif NOT structKeyExists(fieldMap, form.section)>
  <div class="flash flash-danger"><i class="bi bi-exclamation-circle-fill"></i> Unknown settings section.</div>
  <cfabort>
</cfif>

<cfset fields = fieldMap[form.section]>

<cftry>
  <cfloop list="#fields#" item="local.field">
    <cfparam name="form[local.field]" default="">
    <cfquery datasource="#application.dsn#">
      INSERT INTO settings (setting_key, setting_value)
      VALUES (
        <cfqueryparam value="#local.field#"             cfsqltype="cf_sql_varchar">,
        <cfqueryparam value="#trim(form[local.field])#" cfsqltype="cf_sql_varchar">
      )
      ON DUPLICATE KEY UPDATE
        setting_value = <cfqueryparam value="#trim(form[local.field])#" cfsqltype="cf_sql_varchar">
    </cfquery>

    <!--- Update live application scope --->
    <cfset application.settings[local.field] = trim(form[local.field])>
  </cfloop>

  <div class="flash flash-success">
    <i class="bi bi-check-circle-fill"></i>
    Settings saved successfully.
  </div>

<cfcatch type="any">
  <cflog file="nativepyro_errors" text="settings_save.cfm error: #cfcatch.message#">
  <div class="flash flash-danger">
    <i class="bi bi-exclamation-circle-fill"></i>
    Error saving settings: <cfoutput>#htmlEditFormat(cfcatch.message)#</cfoutput>
  </div>
</cfcatch>
</cftry>
