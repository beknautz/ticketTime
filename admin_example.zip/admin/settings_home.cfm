<!--- admin/settings_home.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfset request.pageTitle = "Homepage Settings">

<!--- Load slides --->
<cfquery name="getSlides" datasource="#application.dsn#">
  SELECT * FROM slides ORDER BY sort_order ASC
</cfquery>

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div id="settings-result"></div>

<!--- ============================================================
  HERO SECTION EDITOR
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>🔥 Hero Section</h3>
    <span style="font-size:0.75rem;color:var(--text-muted)">The big banner at the top of the homepage</span>
  </div>
  <div class="admin-card-body">

    <!--- Text content form (no file upload — plain JSON) --->
    <form
      hx-post="/admin/settings_save.cfm"
      hx-target="##settings-result"
      hx-swap="innerHTML"
      hx-indicator="##hero-spinner"
    >
      <input type="hidden" name="section" value="hero">

      <div class="row" style="margin-bottom:1rem">
        <div>
          <label class="form-label">Hero Headline</label>
          <input type="text" name="hero_headline" class="form-control"
            value="#htmlEditFormat(application.settings.hero_headline)#">
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.25rem">The big word(s) at top (e.g. "Ignite")</div>
        </div>
        <div>
          <label class="form-label">Hero Button Text</label>
          <input type="text" name="hero_btn_text" class="form-control"
            value="#htmlEditFormat(application.settings.hero_btn_text)#">
        </div>
      </div>

      <div style="margin-bottom:1rem">
        <label class="form-label">Hero Subheadline</label>
        <textarea name="hero_subheadline" class="form-control" rows="3">#htmlEditFormat(application.settings.hero_subheadline)#</textarea>
      </div>

      <button type="submit" class="btn btn-fire btn-sm">
        <span id="hero-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        Save Hero Text
      </button>
    </form>

    <!--- Divider --->
    <div style="margin:2rem 0;border-top:1px solid var(--border-color)"></div>

    <!--- Hero Image upload — separate multipart form --->
    <div>
      <label class="form-label" style="margin-bottom:0.75rem">Hero Background Image</label>

      <!--- Current image preview --->
      <cfset local.heroImage = structKeyExists(application.settings, "hero_image") ? trim(application.settings.hero_image) : "">
      <div id="hero-image-wrap" style="margin-bottom:1.25rem">
        <cfif len(local.heroImage)>
          <div style="position:relative;border-radius:var(--border-radius-lg);overflow:hidden;border:1px solid var(--border-color);max-width:600px">
            <img
              id="hero-img-preview"
              src="#application.rootURL#/assets/img/uploads/hero/#local.heroImage#"
              alt="Hero background"
              style="width:100%;height:220px;object-fit:cover;display:block"
            >
            <div style="position:absolute;inset:0;background:linear-gradient(to right,rgba(255,69,0,0.4),transparent);pointer-events:none"></div>
            <div style="position:absolute;bottom:0.75rem;left:0.75rem;font-family:var(--font-heading);font-size:0.7rem;font-weight:700;letter-spacing:0.1em;text-transform:uppercase;color:rgba(255,255,255,0.7)">Current hero image</div>
          </div>
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.4rem">File: #local.heroImage#</div>
        <cfelse>
          <div style="width:100%;max-width:600px;height:160px;background:var(--bg-elevated);border:1px dashed var(--border-color);border-radius:var(--border-radius-lg);display:flex;align-items:center;justify-content:center;flex-direction:column;gap:0.5rem;margin-bottom:0.5rem">
            <img id="hero-img-preview" src="" alt="" style="display:none;width:100%;height:100%;object-fit:cover">
            <span style="font-size:2rem;opacity:0.3">🖼️</span>
            <span style="font-size:0.8rem;color:var(--text-muted)">No hero image set — gradient background active</span>
          </div>
        </cfif>
      </div>

      <form
        hx-post="/admin/hero_image_save.cfm"
        hx-target="##hero-image-result"
        hx-swap="innerHTML"
        hx-encoding="multipart/form-data"
        hx-indicator="##img-spinner"
        style="display:flex;align-items:flex-end;gap:1rem;flex-wrap:wrap"
      >
        <div style="flex:1;min-width:280px">
          <label class="form-label">Upload New Hero Image</label>
          <input
            type="file"
            name="hero_image_file"
            class="form-control"
            accept="image/jpeg,image/png,image/gif,image/webp"
            data-preview="hero-img-preview"
            style="font-size:0.85rem"
            required
          >
          <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">
            Recommended: 1920×1080px or wider. JPG/PNG/WEBP. The image will be covered by a dark fire overlay.
          </div>
        </div>

        <div style="display:flex;gap:0.75rem;align-items:center;flex-shrink:0">
          <button type="submit" class="btn btn-fire btn-sm">
            <span id="img-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
            <i class="bi bi-upload"></i> Upload Image
          </button>

          <cfif len(local.heroImage)>
          <button
            type="button"
            class="btn btn-sm"
            style="background:rgba(220,53,69,0.1);color:##f48995;border:1px solid rgba(220,53,69,0.2)"
            hx-post="/admin/hero_image_remove.cfm"
            hx-target="##hero-image-result"
            hx-swap="innerHTML"
            hx-confirm="Remove the hero image? The gradient background will be used instead."
          >
            <i class="bi bi-trash"></i> Remove
          </button>
          </cfif>
        </div>
      </form>

      <div id="hero-image-result" style="margin-top:1rem"></div>

    </div>

  </div>
</div>

<!--- ============================================================
  ABOUT SECTION EDITOR
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>📖 About / Our Story Section</h3>
  </div>
  <div class="admin-card-body">
    <form
      hx-post="/admin/settings_save.cfm"
      hx-target="##settings-result"
      hx-swap="innerHTML"
      hx-indicator="##about-spinner"
    >
      <input type="hidden" name="section" value="about">

      <div style="margin-bottom:1rem">
        <label class="form-label">Section Headline</label>
        <input type="text" name="about_headline" class="form-control"
          value="#htmlEditFormat(application.settings.about_headline)#">
      </div>

      <div style="margin-bottom:1rem">
        <label class="form-label">About / Story Text</label>
        <textarea name="about_text" class="form-control" rows="8">#htmlEditFormat(application.settings.about_text)#</textarea>
      </div>

      <button type="submit" class="btn btn-fire btn-sm">
        <span id="about-spinner" class="htmx-indicator me-2" style="display:inline-block;width:12px;height:12px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite"></span>
        Save About
      </button>
    </form>
  </div>
</div>

<!--- ============================================================
  SLIDES MANAGER
  ============================================================ --->
<div class="admin-card" style="margin-bottom:1.5rem">
  <div class="admin-card-header">
    <h3>🎠 Hero Slides</h3>
    <a href="/admin/slides_form.cfm" class="btn btn-outline btn-sm"><i class="bi bi-plus-lg"></i> Add Slide</a>
  </div>
  <table class="admin-table">
    <thead>
      <tr>
        <th>Headline</th>
        <th>Button</th>
        <th>Sort</th>
        <th>Status</th>
        <th></th>
      </tr>
    </thead>
    <tbody id="slides-tbody">
      <cfif getSlides.recordCount EQ 0>
        <tr><td colspan="5" style="text-align:center;color:var(--text-muted);padding:2rem">No slides yet. Add one above.</td></tr>
      <cfelse>
        <cfloop query="getSlides">
        <tr id="slide-row-#slide_id#">
          <td style="font-weight:600;color:var(--text-primary)">#htmlEditFormat(headline)#</td>
          <td>#htmlEditFormat(btn_text)#</td>
          <td>#sort_order#</td>
          <td>
            <cfif is_active>
              <span class="status-badge status-active">Active</span>
            <cfelse>
              <span class="status-badge status-inactive">Inactive</span>
            </cfif>
          </td>
          <td>
            <div style="display:flex;gap:0.4rem">
              <a href="/admin/slides_form.cfm?slide_id=#slide_id#" class="btn btn-outline btn-sm">Edit</a>
              <button
                class="btn btn-sm"
                style="background:rgba(220,53,69,0.1);color:##f48995;border:1px solid rgba(220,53,69,0.2)"
                hx-post="/admin/slides_delete.cfm"
                hx-vals='{"slide_id": "#slide_id#"}'
                hx-target="##slide-row-#slide_id#"
                hx-swap="outerHTML swap:300ms"
                hx-confirm="Delete this slide?"
              >Del</button>
            </div>
          </td>
        </tr>
        </cfloop>
      </cfif>
    </tbody>
  </table>
</div>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
