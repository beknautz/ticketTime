<!--- admin/products_form.cfm --->
<cfinclude template="/includes/auth_check.cfm">
<cfparam name="url.product_id" default="0">

<cfset isEdit = val(url.product_id) GT 0>
<cfset request.pageTitle = isEdit ? "Edit Product" : "Add Product">

<!--- Load categories --->
<cfquery name="getCategories" datasource="#application.dsn#">
  SELECT category_id, name FROM categories WHERE is_active = 1 ORDER BY sort_order ASC, name ASC
</cfquery>

<!--- Load existing record for edit --->
<cfif isEdit>
  <cftry>
    <cfquery name="getRecord" datasource="#application.dsn#">
      SELECT * FROM products
      WHERE product_id = <cfqueryparam value="#val(url.product_id)#" cfsqltype="cf_sql_integer">
    </cfquery>
    <cfif getRecord.recordCount EQ 0>
      <cflocation url="/admin/products_list.cfm" addtoken="false">
    </cfif>
  <cfcatch type="any">
    <cflocation url="/admin/products_list.cfm" addtoken="false">
  </cfcatch>
  </cftry>
</cfif>

<!--- Defaults for new product --->
<cfparam name="getRecord.product_id"  default="0">
<cfparam name="getRecord.category_id" default="">
<cfparam name="getRecord.name"        default="">
<cfparam name="getRecord.slug"        default="">
<cfparam name="getRecord.description" default="">
<cfparam name="getRecord.sku"         default="">
<cfparam name="getRecord.price"       default="0">
<cfparam name="getRecord.image"       default="">
<cfparam name="getRecord.image2"      default="">
<cfparam name="getRecord.image3"      default="">
<cfparam name="getRecord.tag"         default="">
<cfparam name="getRecord.is_featured" default="0">
<cfparam name="getRecord.is_new"      default="0">
<cfparam name="getRecord.is_active"   default="1">
<cfparam name="getRecord.sort_order"  default="0">

<cfinclude template="/themes/#application.theme#/layouts/admin_open.cfm">

<cfoutput>

<div style="margin-bottom:1.5rem">
  <a href="/admin/products_list.cfm" style="font-size:0.8rem;color:var(--text-muted)">&larr; Back to Products</a>
</div>

<div id="form-messages" style="margin-bottom:1rem"></div>

<!--- ============================================================
  MAIN DATA FORM
  Plain POST — NO hx-encoding multipart, NO file inputs.
  This ensures all form.* text fields are always accessible in CF.
  Images are handled separately below via their own upload forms.
  ============================================================ --->
<form
  hx-post="/admin/products_save.cfm"
  hx-target="##form-messages"
  hx-swap="innerHTML"
  hx-indicator="##save-spinner"
>
  <input type="hidden" name="product_id" value="#getRecord.product_id#">

  <div style="display:grid;grid-template-columns:2fr 1fr;gap:2rem;align-items:start">

    <!--- ---- LEFT COLUMN ---- --->
    <div>

      <!--- Product Info --->
      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Product Information</h3></div>
        <div class="admin-card-body">

          <div class="mb-3">
            <label class="form-label">Product Name *</label>
            <input type="text" name="name" class="form-control"
              value="#htmlEditFormat(getRecord.name)#" required
              hx-on:input="document.getElementById('slug-preview').value = this.value.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$$/g,'')">
          </div>

          <div class="mb-3">
            <label class="form-label">URL Slug *</label>
            <input type="text" id="slug-preview" name="slug" class="form-control"
              value="#htmlEditFormat(getRecord.slug)#" required
              style="font-family:var(--font-mono);font-size:0.85rem">
            <div style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">Lowercase letters, numbers and hyphens only</div>
          </div>

          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" class="form-control" rows="7">#htmlEditFormat(getRecord.description)#</textarea>
          </div>

        </div>
      </div>

      <!--- ============================================================
        IMAGE UPLOAD PANELS
        Each is its own self-contained multipart form that posts to
        products_image_save.cfm. Completely separate from the data form.
        ============================================================ --->
      <div class="admin-card">
        <div class="admin-card-header"><h3>Product Images</h3></div>
        <div class="admin-card-body">
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:1.5rem">

            <!--- Image 1 --->
            <div>
              <label class="form-label">Main Image</label>
              <div class="img-preview-wrap" id="img1-wrap">
                <cfif len(getRecord.image)>
                  <img id="img1-preview"
                    src="#application.uploadURL#products/#getRecord.image#"
                    alt="" style="width:100%;height:100%;object-fit:contain;padding:4px">
                <cfelse>
                  <img id="img1-preview" src="" alt="" style="display:none">
                </cfif>
              </div>
              <div id="img1-result" style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">
                <cfif len(getRecord.image)>#getRecord.image#</cfif>
              </div>
              <form
                hx-post="/admin/products_image_save.cfm"
                hx-target="##img1-result"
                hx-swap="innerHTML"
                hx-encoding="multipart/form-data"
                hx-indicator="##img1-spinner"
                style="margin-top:0.5rem"
              >
                <input type="hidden" name="product_id"    value="#getRecord.product_id#">
                <input type="hidden" name="image_slot"    value="1">
                <input type="hidden" name="existing_image" value="#htmlEditFormat(getRecord.image)#">
                <input type="file" name="image_file" class="form-control"
                  style="font-size:0.8rem;padding:0.4rem;margin-bottom:0.4rem"
                  onchange="previewImg(this,'img1-preview')">
                <button type="submit" class="btn btn-outline btn-sm" style="width:100%">
                  <span id="img1-spinner" class="htmx-indicator" style="display:inline-block;width:10px;height:10px;border:2px solid rgba(255,255,255,0.3);border-top-color:currentColor;border-radius:50%;animation:spin 0.7s linear infinite;margin-right:4px"></span>
                  Upload
                </button>
              </form>
            </div>

            <!--- Image 2 --->
            <div>
              <label class="form-label">Image 2</label>
              <div class="img-preview-wrap" id="img2-wrap">
                <cfif len(getRecord.image2)>
                  <img id="img2-preview"
                    src="#application.uploadURL#products/#getRecord.image2#"
                    alt="" style="width:100%;height:100%;object-fit:contain;padding:4px">
                <cfelse>
                  <img id="img2-preview" src="" alt="" style="display:none">
                </cfif>
              </div>
              <div id="img2-result" style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">
                <cfif len(getRecord.image2)>#getRecord.image2#</cfif>
              </div>
              <form
                hx-post="/admin/products_image_save.cfm"
                hx-target="##img2-result"
                hx-swap="innerHTML"
                hx-encoding="multipart/form-data"
                hx-indicator="##img2-spinner"
                style="margin-top:0.5rem"
              >
                <input type="hidden" name="product_id"    value="#getRecord.product_id#">
                <input type="hidden" name="image_slot"    value="2">
                <input type="hidden" name="existing_image" value="#htmlEditFormat(getRecord.image2)#">
                <input type="file" name="image_file" class="form-control"
                  style="font-size:0.8rem;padding:0.4rem;margin-bottom:0.4rem"
                  onchange="previewImg(this,'img2-preview')">
                <button type="submit" class="btn btn-outline btn-sm" style="width:100%">
                  <span id="img2-spinner" class="htmx-indicator" style="display:inline-block;width:10px;height:10px;border:2px solid rgba(255,255,255,0.3);border-top-color:currentColor;border-radius:50%;animation:spin 0.7s linear infinite;margin-right:4px"></span>
                  Upload
                </button>
              </form>
            </div>

            <!--- Image 3 --->
            <div>
              <label class="form-label">Image 3</label>
              <div class="img-preview-wrap" id="img3-wrap">
                <cfif len(getRecord.image3)>
                  <img id="img3-preview"
                    src="#application.uploadURL#products/#getRecord.image3#"
                    alt="" style="width:100%;height:100%;object-fit:contain;padding:4px">
                <cfelse>
                  <img id="img3-preview" src="" alt="" style="display:none">
                </cfif>
              </div>
              <div id="img3-result" style="font-size:0.72rem;color:var(--text-muted);margin-top:0.3rem">
                <cfif len(getRecord.image3)>#getRecord.image3#</cfif>
              </div>
              <form
                hx-post="/admin/products_image_save.cfm"
                hx-target="##img3-result"
                hx-swap="innerHTML"
                hx-encoding="multipart/form-data"
                hx-indicator="##img3-spinner"
                style="margin-top:0.5rem"
              >
                <input type="hidden" name="product_id"    value="#getRecord.product_id#">
                <input type="hidden" name="image_slot"    value="3">
                <input type="hidden" name="existing_image" value="#htmlEditFormat(getRecord.image3)#">
                <input type="file" name="image_file" class="form-control"
                  style="font-size:0.8rem;padding:0.4rem;margin-bottom:0.4rem"
                  onchange="previewImg(this,'img3-preview')">
                <button type="submit" class="btn btn-outline btn-sm" style="width:100%">
                  <span id="img3-spinner" class="htmx-indicator" style="display:inline-block;width:10px;height:10px;border:2px solid rgba(255,255,255,0.3);border-top-color:currentColor;border-radius:50%;animation:spin 0.7s linear infinite;margin-right:4px"></span>
                  Upload
                </button>
              </form>
            </div>

          </div>

          <cfif NOT isEdit>
          <div style="font-size:0.78rem;color:var(--text-muted);margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color)">
            <i class="bi bi-info-circle"></i> Save the product first, then upload images.
          </div>
          </cfif>

        </div>
      </div>

    </div>

    <!--- ---- RIGHT COLUMN ---- --->
    <div>

      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Organization</h3></div>
        <div class="admin-card-body">

          <div class="mb-3">
            <label class="form-label">Category *</label>
            <select name="category_id" class="form-select" required>
              <option value="">— Select —</option>
              <cfloop query="getCategories">
              <option value="#category_id#" <cfif getRecord.category_id EQ category_id>selected</cfif>>#htmlEditFormat(name)#</option>
              </cfloop>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">SKU / Item Code</label>
            <input type="text" name="sku" class="form-control"
              value="#htmlEditFormat(getRecord.sku)#"
              style="font-family:var(--font-mono)" placeholder="WC-001">
          </div>

          <div class="mb-3">
            <label class="form-label">Tag</label>
            <select name="tag" class="form-select">
              <option value="">None</option>
              <option value="WC" <cfif getRecord.tag EQ "WC">selected</cfif>>WC</option>
              <option value="CE" <cfif getRecord.tag EQ "CE">selected</cfif>>CE</option>
		   <option value="MP" <cfif getRecord.tag EQ "MP">selected</cfif>>MP</option>
	   <option value="MRCC" <cfif getRecord.tag EQ "MRCC">selected</cfif>>MRCC</option>
            </select>
          </div>

          <div class="mb-3">
            <label class="form-label">Price (0 = Call for Price)</label>
            <input type="number" name="price" class="form-control"
              value="#getRecord.price#" min="0" step="0.01">
          </div>

          <div class="mb-3">
            <label class="form-label">Sort Order</label>
            <input type="number" name="sort_order" class="form-control"
              value="#getRecord.sort_order#" min="0">
          </div>

        </div>
      </div>

      <div class="admin-card" style="margin-bottom:1.5rem">
        <div class="admin-card-header"><h3>Status &amp; Flags</h3></div>
        <div class="admin-card-body">

          <input type="hidden" name="is_active"   value="0">
          <input type="hidden" name="is_featured" value="0">
          <input type="hidden" name="is_new"      value="0">

          <div class="mb-3 form-check">
            <input type="checkbox" name="is_active" value="1" class="form-check-input" id="chk_active"
              <cfif getRecord.is_active>checked</cfif>>
            <label class="form-check-label" for="chk_active" style="color:var(--text-secondary);font-family:var(--font-heading)">
              Active (visible on site)
            </label>
          </div>

          <div class="mb-3 form-check">
            <input type="checkbox" name="is_featured" value="1" class="form-check-input" id="chk_featured"
              <cfif getRecord.is_featured>checked</cfif>>
            <label class="form-check-label" for="chk_featured" style="color:var(--text-secondary);font-family:var(--font-heading)">
              Featured on Homepage
            </label>
          </div>

          <div class="mb-3 form-check">
            <input type="checkbox" name="is_new" value="1" class="form-check-input" id="chk_new"
              <cfif getRecord.is_new>checked</cfif>>
            <label class="form-check-label" for="chk_new" style="color:var(--text-secondary);font-family:var(--font-heading)">
              Show as New Arrival
            </label>
          </div>

        </div>
      </div>

      <!--- Save --->
      <button type="submit" class="btn btn-fire" style="width:100%">
        <span id="save-spinner" class="htmx-indicator me-2"
          style="display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,0.3);border-top-color:white;border-radius:50%;animation:spin 0.7s linear infinite">
        </span>
        <i class="bi bi-check-lg"></i>
        #isEdit ? "Update Product" : "Create Product"#
      </button>

      <cfif isEdit>
      <a href="/product.cfm?slug=#htmlEditFormat(getRecord.slug)#" target="_blank"
        class="btn btn-outline" style="width:100%;margin-top:0.75rem;text-align:center;display:block">
        <i class="bi bi-eye"></i> View on Site
      </a>
      </cfif>

    </div>

  </div>

</form>

<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

<script>
function previewImg(input, previewId) {
  var preview = document.getElementById(previewId);
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      preview.src = e.target.result;
      preview.style.display = 'block';
    };
    reader.readAsDataURL(input.files[0]);
  }
}
</script>

</cfoutput>

<cfinclude template="/themes/#application.theme#/layouts/admin_close.cfm">
